<?php

$start_text = "Hello, I'm Cleanify! How can i help you?\nIf this is your first time using me, please read the help section <3";
$supp_text = "Message @FormerlyGod for support.";
$channelerror_text = "The message you sent is not related to any channel. Please proceed according to the help video :)";
$diffrentChannelError_text = "Bro the messages you sent are from different channels :/";
$adminerror_text = "First, you need to make me an admin channel and give me the necessary access. Please try again after doing this!";
$deniederror_text = "You are not an admin of this channel :/";
$invalid_text = "Sorry, I didn't understand. Please choose from the menu!";
$firstmsg_text = "Please forward the message you want me to start cleaning from:";
$secondmsg_text = "Please forward the message you want me to stop cleaning from:";
$tnx_text = "I cleaned your channel, thank you for using me!";
$help_text = "This video shows you how to use the bot!";
$delete_command_txt = "Delete message for me!";
$help_command_txt = "Help";
$support_command_txt = "Support";

?>